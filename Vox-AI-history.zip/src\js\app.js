/* ==========================================================================
   Smart History Education AI - Main Application Controller
   ========================================================================== */

import { PRESET_LESSONS } from './presetLessons.js';
import { SpeechEngine } from './speechEngine.js';
import { VideoGenerator } from './videoGenerator.js';
import { StoryboardEditor } from './storyboardEditor.js';
import { VideoPipelineManager } from './videoPipelineManager.js';
import { globalCharacterRefMgr } from './characterReferenceManager.js';

document.addEventListener('DOMContentLoaded', () => {
  // DOM Selectors
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const pipelineStatusBadge = document.getElementById('pipelineStatusBadge');
  const presetContainer = document.getElementById('presetContainer');
  const topicTitleInput = document.getElementById('topicTitleInput');
  
  const micBox = document.getElementById('micBox');
  const micBtn = document.getElementById('micBtn');
  const micPauseBtn = document.getElementById('micPauseBtn');
  const micStatusText = document.getElementById('micStatusText');
  const waveformCanvas = document.getElementById('waveformCanvas');
  
  const transcriptTextarea = document.getElementById('transcriptTextarea');
  const generateVideoBtn = document.getElementById('generateVideoBtn');
  
  const addCharacterBtn = document.getElementById('addCharacterBtn');
  const charFileInput = document.getElementById('charFileInput');
  const characterRefGrid = document.getElementById('characterRefGrid');

  const mainCanvas = document.getElementById('mainCanvas');
  const html5VideoPlayer = document.getElementById('html5VideoPlayer');
  const aiProcessingOverlay = document.getElementById('aiProcessingOverlay');
  const aiStepTitle = document.getElementById('aiStepTitle');
  const aiStepDetails = document.getElementById('aiStepDetails');
  const pipelineLogConsole = document.getElementById('pipelineLogConsole');
  const errorAlertBox = document.getElementById('errorAlertBox');
  const errorMessageContent = document.getElementById('errorMessageContent');
  const retryBtn = document.getElementById('retryBtn');
  
  const playPauseBtn = document.getElementById('playPauseBtn');
  const restartBtn = document.getElementById('restartBtn');
  const subtitleToggleBtn = document.getElementById('subtitleToggleBtn');
  const fullscreenBtn = document.getElementById('fullscreenBtn');
  
  const currentTimeDisplay = document.getElementById('currentTimeDisplay');
  const totalTimeDisplay = document.getElementById('totalTimeDisplay');
  const progressBarWrapper = document.getElementById('progressBarWrapper');
  const progressBarFill = document.getElementById('progressBarFill');
  
  const exportVideoBtn = document.getElementById('exportVideoBtn');
  const downloadScriptBtn = document.getElementById('downloadScriptBtn');

  const storyboardGrid = document.getElementById('storyboardGrid');
  const characterRosterGrid = document.getElementById('characterRosterGrid');

  // Application State
  let currentAnalysis = null;
  let speechEngine = null;
  let videoGenerator = null;
  let storyboardEditor = null;
  let pipelineManager = null;
  let activeVideoUrl = null;
  let selectedStyle = '3d_characters';
  let selectedPreset = 'fast_preview';

  /* 1. Initialize Engines */
  videoGenerator = new VideoGenerator(
    mainCanvas,
    (progressRatio, currentSec, totalSec) => {
      if (html5VideoPlayer.style.display === 'none') {
        progressBarFill.style.width = `${progressRatio * 100}%`;
        currentTimeDisplay.textContent = formatTime(currentSec);
        totalTimeDisplay.textContent = formatTime(totalSec);
      }
    },
    () => {}
  );

  storyboardEditor = new StoryboardEditor(
    storyboardGrid,
    characterRosterGrid,
    (updatedScenes) => {
      if (videoGenerator && currentAnalysis) {
        videoGenerator.updateScenes(updatedScenes);
      }
    }
  );

  // Initialize End-to-End Pipeline Manager with Stage Logging
  pipelineManager = new VideoPipelineManager(
    (state, message, logs) => {
      updatePipelineHUD(state, message, logs);
    },
    (serverVideoUrl, analysisData, style, presetMode) => {
      currentAnalysis = analysisData;
      storyboardEditor.loadData(analysisData.scenes, analysisData.figures);
      videoGenerator.loadScript(analysisData);
      videoGenerator.setVariation(style);

      if (serverVideoUrl) {
        activeVideoUrl = serverVideoUrl;
        html5VideoPlayer.src = serverVideoUrl;
        html5VideoPlayer.load();

        html5VideoPlayer.addEventListener('loadedmetadata', () => {
          const duration = html5VideoPlayer.duration;
          if (duration && duration > 0 && !isNaN(duration)) {
            html5VideoPlayer.style.display = 'block';
            mainCanvas.style.display = 'none';

            totalTimeDisplay.textContent = formatTime(duration);
            currentTimeDisplay.textContent = '00:00';

            html5VideoPlayer.play().then(() => {
              updatePlayPauseIcon(true);
            }).catch(e => console.warn('Autoplay error:', e));

            aiProcessingOverlay.classList.remove('active');
            errorAlertBox.style.display = 'none';
            pipelineManager.setState('VIDEO_READY', `Video ready (${formatTime(duration)})`);
            showToast(`Video Compiled! Duration: ${formatTime(duration)}`, 'success');
          } else {
            fallbackToCanvasStream(analysisData, style);
          }
        }, { once: true });

        html5VideoPlayer.addEventListener('error', () => {
          fallbackToCanvasStream(analysisData, style);
        }, { once: true });
      } else {
        fallbackToCanvasStream(analysisData, style);
      }
    },
    (errorMessage) => {
      aiProcessingOverlay.classList.remove('active');
      errorMessageContent.textContent = errorMessage;
      errorAlertBox.style.display = 'block';
    }
  );

  function fallbackToCanvasStream(analysisData, style) {
    console.log('[Fast Video Stream] Playing fast video preview stream...');
    html5VideoPlayer.style.display = 'none';
    mainCanvas.style.display = 'block';

    videoGenerator.loadScript(analysisData);
    videoGenerator.setVariation(style);
    videoGenerator.startPlayback();

    aiProcessingOverlay.classList.remove('active');
    errorAlertBox.style.display = 'none';

    const totalDur = analysisData.totalDuration || videoGenerator.totalDuration;
    totalTimeDisplay.textContent = formatTime(totalDur);
    currentTimeDisplay.textContent = '00:00';
    updatePlayPauseIcon(true);

    pipelineManager.setState('VIDEO_READY', `Fast Preview Ready (${formatTime(totalDur)})`);
    showToast(`Fast Video Preview Stream Active! Duration: ${formatTime(totalDur)}`, 'success');
  }

  // Initialize Speech Engine
  speechEngine = new SpeechEngine(
    (transcript) => {
      transcriptTextarea.value = transcript;
      const title = topicTitleInput.value.trim() || 'History Lesson';
      pipelineManager.handleTranscriptStream(transcript, title);
    },
    (statusText, isRecording) => {
      micStatusText.textContent = statusText;
      if (isRecording) {
        micBox.classList.add('recording');
        micBtn.innerHTML = '<i class="fa-solid fa-stop"></i>';
        pipelineManager.setState('LISTENING', 'Listening...');
      } else {
        micBox.classList.remove('recording');
        micBtn.innerHTML = '<i class="fa-solid fa-microphone"></i>';
        if (transcriptTextarea.value.trim()) {
          pipelineManager.setState('TRANSCRIBING', 'Speech recognized — ready to generate video');
        }
      }
    }
  );

  function updatePipelineHUD(state, message, logs = []) {
    if (pipelineStatusBadge) {
      let icon = '<i class="fa-solid fa-circle-notch fa-spin"></i>';
      if (state === 'IDLE' || state === 'LISTENING') icon = '<i class="fa-solid fa-microphone"></i>';
      if (state === 'VIDEO_READY') icon = '<i class="fa-solid fa-circle-check" style="color:var(--accent-emerald);"></i>';
      if (state === 'FAILED') icon = '<i class="fa-solid fa-triangle-exclamation" style="color:var(--accent-crimson);"></i>';

      pipelineStatusBadge.innerHTML = `${icon} ${state}: ${message}`;
    }

    if (pipelineLogConsole) {
      pipelineLogConsole.innerHTML = logs.map(l => `<div>${l}</div>`).join('');
      pipelineLogConsole.scrollTop = pipelineLogConsole.scrollHeight;
    }

    if (['ANALYZING_TRANSCRIPT', 'PROCESSING_CHARACTER_REFERENCES', 'CREATING_SCENES', 'SUBMITTING_VIDEO_JOB', 'GENERATING_SCENES', 'WAITING_FOR_COMPLETION', 'VALIDATING_VIDEO', 'LOADING_FINAL_VIDEO'].includes(state)) {
      aiProcessingOverlay.classList.add('active');
      aiStepTitle.textContent = `Pipeline: ${state.replace(/_/g, ' ')}`;
      aiStepDetails.innerHTML = `<i class="fa-solid fa-brain"></i> ${message}`;
    } else if (state === 'VIDEO_READY' || state === 'IDLE' || state === 'TRANSCRIBING') {
      aiProcessingOverlay.classList.remove('active');
    }
  }

  /* 2. Character Reference Image Upload Handlers */
  addCharacterBtn.addEventListener('click', () => {
    charFileInput.click();
  });

  charFileInput.addEventListener('change', (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const reader = new FileReader();

    reader.onload = (evt) => {
      const dataUrl = evt.target.result;
      const img = new Image();
      img.src = dataUrl;
      img.onload = () => {
        const defaultName = file.name.split('.')[0].replace(/[-_]/g, ' ');
        const record = globalCharacterRefMgr.addReference(null, defaultName, 'Leader', dataUrl, img);
        renderCharacterRefCards();
        showToast(`Character Reference Uploaded: ${record.name}`, 'success');
      };
    };

    reader.readAsDataURL(file);
    charFileInput.value = '';
  });

  function renderCharacterRefCards() {
    characterRefGrid.innerHTML = '';
    const refs = globalCharacterRefMgr.getAllReferences();

    refs.forEach(ref => {
      const card = document.createElement('div');
      card.className = 'char-ref-card';
      card.innerHTML = `
        <button class="btn-remove-char" title="Remove Character"><i class="fa-solid fa-xmark"></i></button>
        <img src="${ref.dataUrl}" class="char-img-preview" alt="${ref.name}">
        <div class="char-details-inputs">
          <input type="text" class="char-input-text char-name-input" value="${ref.name}" placeholder="Character Name">
          <input type="text" class="char-input-text char-role-input" value="${ref.role}" placeholder="Role (e.g. Leader)">
        </div>
      `;

      card.querySelector('.char-name-input').addEventListener('input', (ev) => {
        ref.name = ev.target.value.trim() || 'Character';
      });

      card.querySelector('.char-role-input').addEventListener('input', (ev) => {
        ref.role = ev.target.value.trim() || 'Leader';
      });

      card.querySelector('.btn-remove-char').addEventListener('click', () => {
        globalCharacterRefMgr.removeReference(ref.id);
        renderCharacterRefCards();
        showToast(`Removed Character ${ref.name}`, 'info');
      });

      characterRefGrid.appendChild(card);
    });
  }

  // Pre-load Default Character Reference Image (Jawaharlal Nehru)
  const defaultNehruImg = new Image();
  defaultNehruImg.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><circle cx="50" cy="50" r="50" fill="%23f59e0b"/><text x="50" y="55" font-size="14" font-weight="bold" text-anchor="middle" fill="%230f172a">Nehru</text></svg>';
  defaultNehruImg.onload = () => {
    globalCharacterRefMgr.addReference('ref_nehru', 'Jawaharlal Nehru', 'Political Leader', defaultNehruImg.src, defaultNehruImg);
    renderCharacterRefCards();
  };

  /* 3. Style Cards & Mode Presets */
  document.querySelectorAll('.style-card').forEach(card => {
    card.addEventListener('click', (e) => {
      document.querySelectorAll('.style-card').forEach(c => c.classList.remove('active'));
      const target = e.currentTarget;
      target.classList.add('active');
      selectedStyle = target.getAttribute('data-style') || '3d_characters';
      videoGenerator.setVariation(selectedStyle);
      showToast(`Selected Style: ${target.querySelector('.style-title').textContent}`, 'info');
    });
  });

  document.querySelectorAll('.mode-preset-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.mode-preset-btn').forEach(b => b.classList.remove('active'));
      const target = e.currentTarget;
      target.classList.add('active');
      selectedPreset = target.getAttribute('data-preset') || 'fast_preview';
      pipelineManager.setPresetMode(selectedPreset);
      showToast(`Generation Mode: ${target.textContent.trim()}`, 'info');
    });
  });

  /* 4. PROMINENT 🎬 GENERATE VIDEO BUTTON & RETRY HANDLER */
  generateVideoBtn.addEventListener('click', () => {
    startGenerationPipeline();
  });

  retryBtn.addEventListener('click', () => {
    errorAlertBox.style.display = 'none';
    startGenerationPipeline();
  });

  function startGenerationPipeline() {
    const transcript = transcriptTextarea.value.trim();
    if (!transcript) {
      showToast('Please speak or enter a history lesson transcript first.', 'warning');
      return;
    }
    const title = topicTitleInput.value.trim() || 'History Lesson';
    showToast(`Generating ${selectedStyle.replace('_', ' ')} video with character references...`, 'info');
    pipelineManager.submitTranscriptForVideo(transcript, title, selectedStyle);
  }

  /* 5. Microphone Controls */
  micBtn.addEventListener('click', () => {
    if (speechEngine.isRecording) {
      speechEngine.stopListening();
    } else {
      speechEngine.startListening(waveformCanvas);
    }
  });

  micPauseBtn.addEventListener('click', () => {
    if (!speechEngine.isRecording) return;
    if (speechEngine.isPaused) {
      speechEngine.resumeListening();
      micPauseBtn.innerHTML = '<i class="fa-solid fa-pause"></i>';
    } else {
      speechEngine.pauseListening();
      micPauseBtn.innerHTML = '<i class="fa-solid fa-play"></i>';
    }
  });

  transcriptTextarea.addEventListener('input', () => {
    const title = topicTitleInput.value.trim() || 'History Lesson';
    pipelineManager.handleTranscriptStream(transcriptTextarea.value, title);
  });

  /* 6. Preset Lessons */
  PRESET_LESSONS.forEach((preset, idx) => {
    const btn = document.createElement('button');
    btn.className = `preset-btn ${idx === 0 ? 'active' : ''}`;
    btn.innerHTML = `<i class="fa-solid fa-landmark"></i> ${preset.title}`;
    btn.addEventListener('click', () => loadPresetLesson(preset.id));
    presetContainer.appendChild(btn);
  });

  loadPresetLesson('plassey-1757');

  function loadPresetLesson(presetId) {
    const preset = PRESET_LESSONS.find(p => p.id === presetId);
    if (!preset) return;

    document.querySelectorAll('.preset-btn').forEach(btn => {
      btn.classList.toggle('active', btn.textContent.includes(preset.title));
    });

    topicTitleInput.value = preset.title;
    transcriptTextarea.value = preset.transcript;

    pipelineManager.submitTranscriptForVideo(preset.transcript, preset.title, selectedStyle);
  }

  /* 7. Player Controls */
  playPauseBtn.addEventListener('click', () => {
    if (html5VideoPlayer.style.display !== 'none') {
      if (html5VideoPlayer.paused) {
        html5VideoPlayer.play();
        updatePlayPauseIcon(true);
      } else {
        html5VideoPlayer.pause();
        updatePlayPauseIcon(false);
      }
    } else {
      if (videoGenerator.isPlaying) {
        videoGenerator.pausePlayback();
        updatePlayPauseIcon(false);
      } else {
        videoGenerator.startPlayback();
        updatePlayPauseIcon(true);
      }
    }
  });

  restartBtn.addEventListener('click', () => {
    if (html5VideoPlayer.style.display !== 'none') {
      html5VideoPlayer.currentTime = 0;
      html5VideoPlayer.play();
    } else {
      videoGenerator.stopPlayback();
      videoGenerator.startPlayback();
    }
    updatePlayPauseIcon(true);
  });

  subtitleToggleBtn.addEventListener('click', () => {
    const isEnabled = !videoGenerator.subtitlesEnabled;
    videoGenerator.toggleSubtitles(isEnabled);
    subtitleToggleBtn.style.color = isEnabled ? 'var(--accent-gold)' : 'var(--text-muted)';
    showToast(isEnabled ? 'Subtitles Enabled' : 'Subtitles Disabled', 'info');
  });

  fullscreenBtn.addEventListener('click', () => {
    const playerCard = document.querySelector('.video-player-hero-card');
    if (!document.fullscreenElement) {
      playerCard.requestFullscreen().catch(err => console.warn(err));
    } else {
      document.exitFullscreen();
    }
  });

  progressBarWrapper.addEventListener('click', (e) => {
    const rect = progressBarWrapper.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, clickX / rect.width));

    if (html5VideoPlayer.style.display !== 'none' && html5VideoPlayer.duration > 0) {
      html5VideoPlayer.currentTime = ratio * html5VideoPlayer.duration;
    } else {
      const targetTime = ratio * videoGenerator.totalDuration;
      videoGenerator.seekTo(targetTime);
    }
  });

  function updatePlayPauseIcon(isPlaying) {
    playPauseBtn.innerHTML = isPlaying ? '<i class="fa-solid fa-pause"></i>' : '<i class="fa-solid fa-play"></i>';
  }

  /* 8. Export Options */
  exportVideoBtn.addEventListener('click', async () => {
    if (activeVideoUrl) {
      const a = document.createElement('a');
      a.href = activeVideoUrl;
      a.download = `${topicTitleInput.value.replace(/\s+/g, '_')}_Video.webm`;
      a.click();
      showToast('Video File Downloaded Successfully!', 'success');
    } else {
      exportVideoBtn.disabled = true;
      exportVideoBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Exporting...';
      videoGenerator.exportVideo((blobUrl) => {
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = `${topicTitleInput.value.replace(/\s+/g, '_')}_Video.webm`;
        a.click();
        exportVideoBtn.disabled = false;
        exportVideoBtn.innerHTML = '<i class="fa-solid fa-download"></i> Download Video (.webm)';
        showToast('Video File Downloaded!', 'success');
      });
    }
  });

  downloadScriptBtn.addEventListener('click', () => {
    if (!currentAnalysis) return;
    const scriptContent = `CHARACTER REFERENCE VIDEO PLATFORM - SCRIPT\nTitle: ${topicTitleInput.value}\nStyle: ${selectedStyle}\nPreset: ${selectedPreset}\nYear: ${currentAnalysis.year}\nLocation: ${currentAnalysis.location}\n\nFULL TRANSCRIPT:\n${transcriptTextarea.value}\n\nSCENES:\n${currentAnalysis.scenes.map((s, i) => `Scene ${i + 1}: ${s.title} (${s.cameraAngle})\nText: ${s.text}\nPrompt: ${s.aiPrompt}\n`).join('\n')}`;

    const blob = new Blob([scriptContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${topicTitleInput.value.replace(/\s+/g, '_')}_Script.txt`;
    a.click();
    showToast('Script Exported!', 'success');
  });

  themeToggleBtn.addEventListener('click', () => {
    document.body.classList.toggle('light-theme');
    const isLight = document.body.classList.contains('light-theme');
    themeToggleBtn.innerHTML = isLight ? '<i class="fa-solid fa-sun"></i>' : '<i class="fa-solid fa-moon"></i>';
  });

  function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = 'toast';
    
    let icon = '<i class="fa-solid fa-circle-info" style="color: var(--accent-gold);"></i>';
    if (type === 'success') icon = '<i class="fa-solid fa-circle-check" style="color: var(--accent-emerald);"></i>';
    if (type === 'warning') icon = '<i class="fa-solid fa-triangle-exclamation" style="color: var(--accent-crimson);"></i>';

    toast.innerHTML = `${icon} <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  function formatTime(seconds) {
    if (!seconds || isNaN(seconds) || seconds <= 0) return '00:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
});
