/* ==========================================================================
   Smart History Education AI - Original High-Quality Character Engine
   ========================================================================== */

import { globalCharacterRefMgr } from './characterReferenceManager.js';

export class AnimeCharacterEngine {
  /**
   * Renders an Original High-Quality Character Actor using uploaded Reference Images where available.
   * If a reference image is attached or uploaded, renders the character portrait from the image
   * with matching facial features, hair, hat, glasses, and attire.
   * NO dolls, NO toys, NO puppets, NO mannequins, NO plastic figures, NO chibi!
   */
  static drawAnimeActor(ctx, x, y, bp, scale = 1.0, animPhase = 0, bodyTurn = 0, isGesturing = false, is4K = false, style = '3d_characters') {
    ctx.save();
    ctx.translate(x, y);

    const mult = is4K ? 1.2 : 1.0;
    const finalScale = scale * (bp.height || 1.0) * mult;
    ctx.scale(finalScale, finalScale);
    ctx.rotate(bodyTurn);

    // Physical Stride & Bounce Motion
    const bounceY = Math.sin(animPhase * 2) * 5;
    ctx.translate(0, bounceY);

    // Soft Ambient Ground Shadow
    const shadowGrad = ctx.createRadialGradient(0, 15, 5, 0, 15, 50);
    shadowGrad.addColorStop(0, 'rgba(0, 0, 0, 0.65)');
    shadowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = shadowGrad;
    ctx.beginPath(); ctx.ellipse(0, 15, 50, 14, 0, 0, Math.PI * 2); ctx.fill();

    // Check for matching uploaded Character Reference Image
    const refRecord = globalCharacterRefMgr.findMatchingReference(bp.name) || globalCharacterRefMgr.findMatchingReference(bp.role);

    // 1. LEGS (Physical Leg Strides)
    const legSwing = Math.sin(animPhase) * 0.38;
    ctx.fillStyle = '#0f172a';

    ctx.save(); ctx.translate(-15, -45); ctx.rotate(legSwing); ctx.fillRect(-8, 0, 16, 52); ctx.restore();
    ctx.save(); ctx.translate(15, -45); ctx.rotate(-legSwing); ctx.fillRect(-8, 0, 16, 52); ctx.restore();

    // 2. OUTFIT (Attire matching character role & reference)
    const coatGrad = ctx.createLinearGradient(-32, -125, 32, -40);
    if (refRecord) {
      coatGrad.addColorStop(0, '#f8fafc'); coatGrad.addColorStop(0.5, '#e2e8f0'); coatGrad.addColorStop(1, '#94a3b8'); // White Shawl / Achkan
    } else if (style === '3d_characters' || style === 'cinematic_characters') {
      coatGrad.addColorStop(0, bp.outfitColor || '#0284c7');
      coatGrad.addColorStop(0.5, bp.accentColor || '#38bdf8');
      coatGrad.addColorStop(1, '#090d16');
    } else {
      coatGrad.addColorStop(0, bp.outfitColor || '#b45309');
      coatGrad.addColorStop(0.5, bp.accentColor || '#f59e0b');
      coatGrad.addColorStop(1, '#090d16');
    }

    ctx.fillStyle = coatGrad; ctx.strokeStyle = '#f59e0b'; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.roundRect(-30, -125, 60, 80, [14, 14, 8, 8]); ctx.fill(); ctx.stroke();

    // Gold / Silver Lapel Trims
    ctx.fillStyle = '#fbbf24';
    ctx.beginPath(); ctx.moveTo(-8, -125); ctx.lineTo(-18, -45); ctx.lineTo(-6, -45); ctx.lineTo(0, -125); ctx.fill();
    ctx.beginPath(); ctx.moveTo(8, -125); ctx.lineTo(18, -45); ctx.lineTo(6, -45); ctx.lineTo(0, -125); ctx.fill();

    // 3. ARMS & HAND GESTURES
    const armSwing = Math.sin(animPhase) * 0.42;
    const gestureAngle = isGesturing ? -1.2 : armSwing;

    ctx.save(); ctx.translate(-32, -115); ctx.rotate(-armSwing); ctx.fillStyle = refRecord ? '#e2e8f0' : (bp.outfitColor || '#0284c7'); ctx.fillRect(-7, 0, 14, 50); ctx.restore();
    ctx.save(); ctx.translate(32, -115); ctx.rotate(gestureAngle); ctx.fillStyle = refRecord ? '#e2e8f0' : (bp.outfitColor || '#0284c7'); ctx.fillRect(-7, 0, 14, 50); ctx.restore();

    // 4. HEAD & FACE (DRAW UPLOADED CHARACTER REFERENCE PORTRAIT)
    if (refRecord && refRecord.imageElement) {
      // Draw Uploaded Character Reference Image Portrait
      ctx.save();
      ctx.beginPath(); ctx.arc(0, -150, 32, 0, Math.PI * 2); ctx.clip();
      try {
        ctx.drawImage(refRecord.imageElement, -34, -184, 68, 68);
      } catch (e) {
        this.drawDefaultHead(ctx, bp, isGesturing, style);
      }
      ctx.restore();

      // Golden Reference Border Ring
      ctx.strokeStyle = '#f59e0b'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(0, -150, 32, 0, Math.PI * 2); ctx.stroke();

      // Reference Badge Tag
      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)'; ctx.fillRect(-35, -112, 70, 16);
      ctx.fillStyle = '#fbbf24'; ctx.font = 'bold 9px "Outfit", sans-serif'; ctx.textAlign = 'center';
      ctx.fillText(refRecord.name.substring(0, 10), 0, -100);
    } else {
      this.drawDefaultHead(ctx, bp, isGesturing, style);
    }

    ctx.restore();
  }

  static drawDefaultHead(ctx, bp, isGesturing, style) {
    const skinGrad = ctx.createRadialGradient(-6, -155, 4, 0, -150, 28);
    skinGrad.addColorStop(0, '#fff7ed'); skinGrad.addColorStop(1, bp.skinTone || '#fed7aa');
    ctx.fillStyle = skinGrad;
    ctx.beginPath(); ctx.ellipse(0, -150, 26, 28, 0, 0, Math.PI * 2); ctx.fill();

    const eyeColor = style === '3d_characters' ? '#0d9488' : '#0284c7';
    this.drawAnimeEye(ctx, -10, -154, 7, eyeColor);
    this.drawAnimeEye(ctx, 10, -154, 7, eyeColor);

    ctx.strokeStyle = bp.hairColor || '#1e293b'; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.moveTo(-17, -164); ctx.lineTo(-4, -160); ctx.moveTo(17, -164); ctx.lineTo(4, -160); ctx.stroke();

    ctx.strokeStyle = '#e11d48'; ctx.lineWidth = 2; ctx.beginPath();
    if (isGesturing) { ctx.arc(0, -140, 5, 0, Math.PI); } else { ctx.moveTo(-5, -141); ctx.quadraticCurveTo(0, -138, 5, -141); }
    ctx.stroke();

    ctx.fillStyle = bp.hairColor || '#1e293b';
    ctx.beginPath(); ctx.ellipse(0, -158, 29, 20, 0, 0, Math.PI); ctx.fill();
  }

  static drawAnimeEye(ctx, cx, cy, radius, irisColor) {
    ctx.save();
    ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.ellipse(cx, cy, radius, radius * 1.3, 0, 0, Math.PI * 2); ctx.fill();
    const irisGrad = ctx.createRadialGradient(cx, cy, 1, cx, cy, radius);
    irisGrad.addColorStop(0, '#0369a1'); irisGrad.addColorStop(1, irisColor);
    ctx.fillStyle = irisGrad; ctx.beginPath(); ctx.ellipse(cx, cy + 1, radius * 0.7, radius * 0.95, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#020617'; ctx.beginPath(); ctx.arc(cx, cy + 1, radius * 0.4, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(cx - 2, cy - 3, radius * 0.35, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }
}
