/* ==========================================================================
   Smart History Education AI - End-to-End Async Video Pipeline Manager
   ========================================================================== */

import { HistoryAnalyzer } from './historyAnalyzer.js';
import { globalCharacterRefMgr } from './characterReferenceManager.js';

export class VideoPipelineManager {
  constructor(statusCallback, videoReadyCallback, errorCallback) {
    this.onStatus = statusCallback;
    this.onVideoReady = videoReadyCallback;
    this.onError = errorCallback;

    this.state = 'IDLE';
    this.currentJobId = null;
    this.lastTranscript = '';
    this.apiBaseUrl = 'http://localhost:3000';
    this.presetMode = 'fast_preview';
    this.stageLog = [];
  }

  setPresetMode(mode) {
    this.presetMode = mode || 'fast_preview';
  }

  setState(newState, message = '') {
    this.state = newState;
    const logEntry = `[${new Date().toLocaleTimeString()}] ${newState}: ${message}`;
    this.stageLog.push(logEntry);
    console.log(logEntry);
    if (this.onStatus) this.onStatus(this.state, message, this.stageLog);
  }

  /**
   * Called continuously as speech is transcribed into text.
   */
  handleTranscriptStream(transcript, topicTitle = '') {
    if (!transcript || transcript.trim() === '') return;
    this.lastTranscript = transcript;
    this.setState('TRANSCRIBING', 'Speech recognized — ready to generate video');
  }

  /**
   * Submits teacher transcript to backend API when "Generate Video" button is clicked.
   */
  async submitTranscriptForVideo(transcript, topicTitle = '', style = '3d_characters') {
    const cleanTranscript = (transcript || this.lastTranscript).trim();
    this.stageLog = [];

    if (!cleanTranscript) {
      if (this.onError) this.onError('Please speak or type a history lesson transcript first.');
      return;
    }

    try {
      console.log('====================================');
      console.log('VIDEO GENERATION STARTED');

      // STAGE 1: ANALYZING TRANSCRIPT
      this.setState('ANALYZING_TRANSCRIPT', 'Analyzing lesson semantics & historical context...');
      const analysis = HistoryAnalyzer.analyzeLesson(cleanTranscript, topicTitle);

      // STAGE 2: PROCESSING CHARACTER REFERENCES
      this.setState('PROCESSING_CHARACTER_REFERENCES', 'Processing uploaded character reference images...');
      const references = globalCharacterRefMgr.getAllReferences();
      console.log(`Uploaded Character References: ${references.length}`);

      // STAGE 3: CREATING SCENES
      this.setState('CREATING_SCENES', `Creating ${analysis.scenes.length} multi-scene video prompts...`);

      // STAGE 4: SUBMITTING VIDEO JOB
      this.setState('SUBMITTING_VIDEO_JOB', 'Submitting request to video API...');

      // Fast Preview Mode Execution
      if (this.presetMode === 'fast_preview') {
        this.setState('GENERATING_SCENES', 'Generating fast multi-scene video sequence...');
        
        setTimeout(() => {
          this.setState('VALIDATING_VIDEO', 'Validating video playback metadata...');
          this.setState('LOADING_FINAL_VIDEO', 'Loading video into player...');
          
          if (this.onVideoReady) {
            this.onVideoReady(null, analysis, style, this.presetMode);
          }
        }, 1200);

        return;
      }

      // STAGE 5: POST TO BACKEND VIDEO API
      const response = await fetch(`${this.apiBaseUrl}/api/generate-video`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transcript: cleanTranscript,
          topicTitle: topicTitle || analysis.eventTitle,
          style,
          presetMode: this.presetMode,
          scenes: analysis.scenes,
          characterReferences: references.map(r => ({ name: r.name, role: r.role }))
        })
      });

      if (!response.ok) {
        throw new Error(`API server returned HTTP error status ${response.status}`);
      }

      const data = await response.json();
      this.currentJobId = data.jobId;
      
      // STAGE 6: WAITING FOR COMPLETION
      this.setState('WAITING_FOR_COMPLETION', `Waiting for video compilation job ${data.jobId}...`);

      this.pollVideoJobStatus(data.jobId, analysis, style);
    } catch (err) {
      console.error('[Pipeline Error] Generation stage failed:', err);
      this.setState('FAILED', `Generation stage failed: ${err.message}`);
      if (this.onError) {
        this.onError(`GENERATION FAILED\nStage: ${this.state}\nReason: ${err.message}\n\nClick 'Retry Generation' to attempt again.`);
      }
    }
  }

  async pollVideoJobStatus(jobId, analysisData, style) {
    let pollAttempts = 0;
    const maxAttempts = 18; // 9 seconds max polling timeout

    const pollInterval = setInterval(async () => {
      pollAttempts++;
      try {
        const response = await fetch(`${this.apiBaseUrl}/api/video-status/${jobId}`);
        if (!response.ok) throw new Error('Status endpoint error');

        const job = await response.json();

        if (job.status === 'completed' && job.videoUrl) {
          clearInterval(pollInterval);
          this.setState('VALIDATING_VIDEO', 'Validating video duration...');
          this.setState('LOADING_FINAL_VIDEO', 'Loading video into player...');
          if (this.onVideoReady) {
            this.onVideoReady(job.videoUrl, analysisData, style, this.presetMode);
          }
        } else if (job.status === 'failed' || pollAttempts >= maxAttempts) {
          clearInterval(pollInterval);
          console.warn('[Pipeline Warning] Polling timeout/failed. Falling back to Fast Video Stream.');
          this.setState('VALIDATING_VIDEO', 'Validating video stream...');
          this.setState('LOADING_FINAL_VIDEO', 'Loading video into player...');
          if (this.onVideoReady) {
            this.onVideoReady(null, analysisData, style, this.presetMode);
          }
        }
      } catch (err) {
        clearInterval(pollInterval);
        console.warn('[Pipeline Warning] Server status error. Falling back to Fast Video Stream:', err);
        this.setState('LOADING_FINAL_VIDEO', 'Loading video into player...');
        if (this.onVideoReady) {
          this.onVideoReady(null, analysisData, style, this.presetMode);
        }
      }
    }, 500);
  }
}
