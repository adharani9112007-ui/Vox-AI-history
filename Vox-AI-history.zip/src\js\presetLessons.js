/* ==========================================================================
   Smart History Education AI - Curated Preset History Lessons
   ========================================================================== */

export const PRESET_LESSONS = [
  {
    id: 'plassey-1757',
    title: 'Battle of Plassey 1757',
    category: 'Indian History',
    era: '18th Century',
    transcript: 'In 1757, the Battle of Plassey was fought between the British East India Company led by Robert Clive and Siraj-ud-Daulah, the Nawab of Bengal. Fought near Palashi on the banks of the Bhagirathi River, this historic battle marked an important turning point in British political control over India. Due to the betrayal of Mir Jafar, Siraj-ud-Daulah was defeated, establishing Company rule in Bengal.',
    extractedData: {
      year: '1757',
      eventTitle: 'Battle of Plassey',
      location: 'Palashi, Bengal, India',
      coordinates: { lat: 23.79, lng: 88.25 },
      regionName: 'Bengal Subah, India',
      figures: [
        { name: 'Siraj-ud-Daulah', role: 'Nawab of Bengal', faction: 'Bengal Sultanate', side: 'Defenders', avatar: '👑' },
        { name: 'Robert Clive', role: 'Commander, EIC', faction: 'British East India Co.', side: 'Attackers', avatar: '⚔️' },
        { name: 'Mir Jafar', role: 'Commander-in-Chief', faction: 'Conspirator', side: 'Betrayer', avatar: '🗡️' }
      ],
      factions: [
        { name: 'Bengal Forces', color: '#ef4444', strength: '50,000 Troops', flag: '🚩' },
        { name: 'British East India Co.', color: '#3b82f6', strength: '3,000 Troops', flag: '🇬🇧' }
      ],
      timeline: [
        { date: 'June 1756', title: 'Siege of Calcutta', desc: 'Nawab Siraj-ud-Daulah recaptures Fort William.' },
        { date: 'Jan 1757', title: 'Treaty of Alinagar', desc: 'Clive retakes Calcutta and forces peace terms.' },
        { date: '23 June 1757', title: 'The Battle of Plassey', desc: 'Clive defeats Bengal forces at Palashi through tactical betrayal.' },
        { date: '1765', title: 'Treaty of Allahabad', desc: 'EIC obtains Diwani rights, starting direct British control in India.' }
      ],
      causesAndEffects: {
        causes: [
          'Conflict over Fort William fortifications in Calcutta',
          'Misuse of duty-free trade passes (Dastaks) by EIC officials',
          'Siraj-ud-Daulah\'s opposition to foreign interference in Bengal'
        ],
        turningPoint: 'Secret pact between Robert Clive and Mir Jafar, causing 30,000 Bengal soldiers to stay inactive during the rainfall.',
        effects: [
          'Mir Jafar installed as puppet Nawab of Bengal',
          'Huge financial plunder of Bengal treasury (£2.5 Million paid to EIC)',
          'Foundation of British territorial Empire in South Asia'
        ]
      }
    }
  },
  {
    id: 'dday-1944',
    title: 'D-Day Normandy Invasion 1944',
    category: 'World War II',
    era: '20th Century',
    transcript: 'On June 6, 1944, known as D-Day, Allied forces launched Operation Overlord, the largest amphibious invasion in human history on the beaches of Normandy, France. Led by General Dwight Eisenhower, over 156,000 Allied troops landed on Utah, Omaha, Gold, Juno, and Sword beaches, opening the Western Front against Nazi Germany and marking the beginning of the liberation of Western Europe.',
    extractedData: {
      year: '1944',
      eventTitle: 'Operation Overlord (D-Day)',
      location: 'Normandy Beaches, France',
      coordinates: { lat: 49.34, lng: -0.88 },
      regionName: 'Normandy, Western Europe',
      figures: [
        { name: 'Dwight D. Eisenhower', role: 'Supreme Allied Commander', faction: 'Allied Powers', side: 'Allies', avatar: '🪖' },
        { name: 'Bernard Montgomery', role: 'Ground Forces Commander', faction: 'British Forces', side: 'Allies', avatar: '🇬🇧' },
        { name: 'Erwin Rommel', role: 'Axis Field Marshal', faction: 'Nazi Germany', side: 'Axis', avatar: '🛡️' }
      ],
      factions: [
        { name: 'Allied Forces (USA/UK/CAN)', color: '#10b981', strength: '156,000 Beach Troops', flag: '🇺🇸🇬🇧🇨🇦' },
        { name: 'Axis German Defenses', color: '#dc2626', strength: '50,000 Coastal Troops', flag: '🇩🇪' }
      ],
      timeline: [
        { date: 'Late 1943', title: 'Tehran Conference', desc: 'Big Three commit to opening Western Front in Europe.' },
        { date: 'June 5, 1944', title: 'Fleet Departure', desc: 'Over 6,900 vessels set sail despite turbulent English Channel weather.' },
        { date: 'June 6, 06:30', title: 'H-Hour Landings', desc: 'Allied troops storm Omaha, Utah, Gold, Juno, & Sword beaches.' },
        { date: 'Aug 25, 1944', title: 'Liberation of Paris', desc: 'Allied armies liberate Paris, breaking German hold on France.' }
      ],
      causesAndEffects: {
        causes: [
          'Need to relieve Soviet Eastern Front pressure by opening Western Front',
          'Strategic dominance of Allied naval and air superiority in Europe',
          'Operation Fortitude deception tricking Axis regarding Pas-de-Calais'
        ],
        turningPoint: 'Securing footholds across Normandy beaches despite fierce German resistance at Omaha Beach.',
        effects: [
          'Liberation of France, Belgium, and Western European nations',
          'Two-front strategic collapse of the Third Reich leading to 1945 Victory',
          'Establishment of post-war European security architecture'
        ]
      }
    }
  },
  {
    id: 'french-rev-1789',
    title: 'Storming of the Bastille 1789',
    category: 'European History',
    era: '18th Century',
    transcript: 'On July 14, 1789, angry citizens of Paris stormed the Bastille medieval fortress and prison. This dramatic event symbolized the end of absolute monarchy under King Louis XVI and feudal privilege, igniting the French Revolution and giving rise to the ideals of Liberty, Equality, and Fraternity.',
    extractedData: {
      year: '1789',
      eventTitle: 'French Revolution Begins',
      location: 'Paris, France',
      coordinates: { lat: 48.85, lng: 2.37 },
      regionName: 'Paris, Kingdom of France',
      figures: [
        { name: 'King Louis XVI', role: 'Monarch of France', faction: 'Bourbon Monarchy', side: 'Crown', avatar: '👑' },
        { name: 'Maximilien Robespierre', role: 'Jacobin Leader', faction: 'National Assembly', side: 'Revolutionaries', avatar: '⚖️' },
        { name: 'Marquis de Lafayette', role: 'Commander, National Guard', faction: 'Reformers', side: 'People', avatar: '⚔️' }
      ],
      factions: [
        { name: 'Revolutionary Third Estate', color: '#f59e0b', strength: 'Parisian Citizens', flag: '🇫🇷' },
        { name: 'Royal Guard & Crown', color: '#6366f1', strength: 'Royal Troops', flag: '⚜️' }
      ],
      timeline: [
        { date: 'May 1789', title: 'Estates-General Convenes', desc: 'Deadlock between Clergy, Nobility, and Third Estate.' },
        { date: 'June 20, 1789', title: 'Tennis Court Oath', desc: 'Third Estate pledges not to disband until Constitution is written.' },
        { date: 'July 14, 1789', title: 'Storming of the Bastille', desc: 'Parisian mob seizes arms and destroys royal fortress.' },
        { date: 'Aug 26, 1789', title: 'Declaration of Rights', desc: 'National Assembly publishes Declaration of Rights of Man.' }
      ],
      causesAndEffects: {
        causes: [
          'Severe financial bankruptcy of France after American Revolutionary War',
          'Widespread famine, bread price spikes, and harsh Third Estate taxation',
          'Enlightenment philosophy questioning divine right of kings'
        ],
        turningPoint: 'The fall of Bastille demonstrated royal troops would not crush popular uprisings in Paris.',
        effects: [
          'Abolition of feudalism and church tithes in France',
          'Drafting of democratic constitution and constitutional monarchy',
          'Global inspiration for modern democratic revolutionary movements'
        ]
      }
    }
  },
  {
    id: 'salt-march-1930',
    title: 'Dandi Salt March 1930',
    category: 'Indian Freedom Movement',
    era: '20th Century',
    transcript: 'In March 1930, Mahatma Gandhi initiated the historic Dandi Salt March, walking 240 miles from Sabarmati Ashram to the coastal village of Dandi, Gujarat. By picking up a handful of natural salt, Gandhi broke the oppressive British Salt Monopoly, sparking non-violent Civil Disobedience across India and inspiring global civil rights movements.',
    extractedData: {
      year: '1930',
      eventTitle: 'Dandi Salt March',
      location: 'Sabarmati to Dandi, Gujarat, India',
      coordinates: { lat: 20.89, lng: 72.80 },
      regionName: 'Gujarat, British India',
      figures: [
        { name: 'Mahatma Gandhi', role: 'Leader of Freedom Movement', faction: 'Indian National Congress', side: 'Satya-grahis', avatar: '🕊️' },
        { name: 'Sarojini Naidu', role: 'Freedom Fighter & Poet', faction: 'Congress Volunteers', side: 'Satya-grahis', avatar: '📜' },
        { name: 'Lord Irwin', role: 'Viceroy of India', faction: 'British Crown Administration', side: 'Colonial Gov', avatar: '👑' }
      ],
      factions: [
        { name: 'Satyagrahis & Volunteers', color: '#10b981', strength: 'Millions nationwide', flag: '🇮🇳' },
        { name: 'British Imperial Police', color: '#64748b', strength: 'Colonial Forces', flag: '🇬🇧' }
      ],
      timeline: [
        { date: 'March 12, 1930', title: 'March Begins', desc: 'Gandhi departs Sabarmati Ashram with 78 trusted marchers.' },
        { date: 'April 5, 1930', title: 'Arrival in Dandi', desc: 'Marchers reach Dandi coastal village after 24 days.' },
        { date: 'April 6, 1930', title: 'Breaking the Salt Law', desc: 'Gandhi lifts natural sea salt, defying British Monopoly law.' },
        { date: 'March 1931', title: 'Gandhi-Irwin Pact', desc: 'Brings Civil Disobedience to temporary halt and release of prisoners.' }
      ],
      causesAndEffects: {
        causes: [
          'High British tax on salt impacting rich and poor alike',
          'Monopoly law forbidding Indians from producing or collecting salt',
          'Purna Swaraj (Complete Independence) resolution of 1929'
        ],
        turningPoint: 'Mass non-violent participation of women and rural peasants shaking colonial moral authority.',
        effects: [
          'Over 60,000 freedom fighters arrested nationwide',
          'Global international newspaper coverage highlighting British colonial injustice',
          'First direct negotiation between Indian leaders and British Raj as equals'
        ]
      }
    }
  }
];
