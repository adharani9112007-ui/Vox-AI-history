/* ==========================================================================
   Smart History Education AI - Persistent Character Profiles & Puppet Animator
   ========================================================================== */

export class CharacterProfiles {
  /**
   * Generates or retrieves a persistent visual character profile.
   */
  static createProfile(name, role = 'Historical Figure', defaultFaction = 'General') {
    const lower = name.toLowerCase();

    // Default template attributes
    let profile = {
      name,
      role,
      faction: defaultFaction,
      avatar: '👤',
      skinTone: '#e0ac69',
      hairColor: '#1a1a1a',
      outfitColor: '#1e293b',
      accentColor: '#f59e0b',
      headwear: 'none', // crown, turban, tricorne, helmet, none
      weapon: 'sword', // sword, musket, banner, scroll
      height: 1.0,
      expression: 'determined', // stern, heroic, determined, calm
      stance: 'heroic'
    };

    // Specific Historical Leaders Recognition
    if (lower.includes('siraj')) {
      profile = {
        name: 'Siraj-ud-Daulah',
        role: 'Nawab of Bengal',
        faction: 'Bengal Sultanate',
        avatar: '👑',
        skinTone: '#c68642',
        hairColor: '#000000',
        outfitColor: '#7f1d1d', // Royal Crimson Tunic
        accentColor: '#fbbf24', // Gold embroidery
        headwear: 'turban',
        weapon: 'scimitar',
        height: 1.05,
        expression: 'stern',
        stance: 'royal'
      };
    } else if (lower.includes('clive') || lower.includes('robert')) {
      profile = {
        name: 'Robert Clive',
        role: 'Commander, East India Co.',
        faction: 'British EIC',
        avatar: '⚔️',
        skinTone: '#ffdbac',
        hairColor: '#4a2c11',
        outfitColor: '#b91c1c', // British Redcoat
        accentColor: '#ffffff', // White sashes
        headwear: 'tricorne',
        weapon: 'sword',
        height: 1.0,
        expression: 'determined',
        stance: 'commanding'
      };
    } else if (lower.includes('mir jafar')) {
      profile = {
        name: 'Mir Jafar',
        role: 'Commander-in-Chief',
        faction: 'Bengal Conspirators',
        avatar: '🗡️',
        skinTone: '#d1a36a',
        hairColor: '#2b2b2b',
        outfitColor: '#1e3a8a', // Deep Blue Velvet
        accentColor: '#9333ea',
        headwear: 'turban',
        weapon: 'dagger',
        height: 0.98,
        expression: 'cautious',
        stance: 'subtle'
      };
    } else if (lower.includes('eisenhower') || lower.includes('ike')) {
      profile = {
        name: 'General Eisenhower',
        role: 'Supreme Commander',
        faction: 'Allied Forces',
        avatar: '🪖',
        skinTone: '#f1c27d',
        hairColor: '#808080',
        outfitColor: '#365314', // Military Olive
        accentColor: '#f59e0b', // General Stars
        headwear: 'helmet',
        weapon: 'binoculars',
        height: 1.02,
        expression: 'heroic',
        stance: 'commanding'
      };
    } else if (lower.includes('gandhi') || lower.includes('mahatma')) {
      profile = {
        name: 'Mahatma Gandhi',
        role: 'Leader of Freedom Movement',
        faction: 'Satyagrahis',
        avatar: '🕊️',
        skinTone: '#c68642',
        hairColor: '#ffffff',
        outfitColor: '#f8fafc', // White Khadi
        accentColor: '#cbd5e1',
        headwear: 'none',
        weapon: 'walking_stick',
        height: 0.95,
        expression: 'calm',
        stance: 'peaceful'
      };
    } else if (lower.includes('napoleon')) {
      profile = {
        name: 'Napoleon Bonaparte',
        role: 'Emperor of France',
        faction: 'French Empire',
        avatar: '⚔️',
        skinTone: '#ffdbac',
        hairColor: '#291d09',
        outfitColor: '#1e1b4b', // Imperial Blue
        accentColor: '#f59e0b', // Gold epaulettes
        headwear: 'bicorne',
        weapon: 'saber',
        height: 0.92,
        expression: 'stern',
        stance: 'royal'
      };
    }

    return profile;
  }

  /**
   * Renders an animated character puppet onto HTML5 canvas with skeletal joint motion.
   */
  static drawCharacterPuppet(ctx, x, y, profile, scale = 1.0, animationPhase = 0, style = 'cinematic') {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scale * profile.height, scale * profile.height);

    // Subtle breathing / walking bounce
    const bounceY = Math.sin(animationPhase * 4) * 4;
    ctx.translate(0, bounceY);

    // Shadow on ground
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.beginPath();
    ctx.ellipse(0, 10, 35, 10, 0, 0, Math.PI * 2);
    ctx.fill();

    // 1. Legs / Boots
    const legAngle = Math.sin(animationPhase * 6) * 0.2;
    ctx.fillStyle = '#0f172a';
    
    // Left Leg
    ctx.save();
    ctx.translate(-12, -40);
    ctx.rotate(legAngle);
    ctx.fillRect(-6, 0, 12, 45);
    ctx.restore();

    // Right Leg
    ctx.save();
    ctx.translate(12, -40);
    ctx.rotate(-legAngle);
    ctx.fillRect(-6, 0, 12, 45);
    ctx.restore();

    // 2. Torso / Tunic Coat
    ctx.fillStyle = profile.outfitColor;
    ctx.strokeStyle = profile.accentColor;
    ctx.lineWidth = 2;

    ctx.beginPath();
    ctx.roundRect(-25, -110, 50, 70, [10, 10, 4, 4]);
    ctx.fill();
    ctx.stroke();

    // Sashes / Gold Buttons
    ctx.fillStyle = profile.accentColor;
    ctx.fillRect(-4, -100, 8, 50);

    // 3. Arms & Weapon
    const armAngle = Math.sin(animationPhase * 6) * 0.3;

    // Left Arm
    ctx.save();
    ctx.translate(-26, -100);
    ctx.rotate(-armAngle);
    ctx.fillStyle = profile.outfitColor;
    ctx.fillRect(-5, 0, 10, 45);
    ctx.restore();

    // Right Arm (Holding Weapon)
    ctx.save();
    ctx.translate(26, -100);
    ctx.rotate(armAngle - 0.2);
    ctx.fillStyle = profile.outfitColor;
    ctx.fillRect(-5, 0, 10, 45);

    // Weapon rendering
    if (profile.weapon === 'scimitar' || profile.weapon === 'sword' || profile.weapon === 'saber') {
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(0, 40);
      ctx.lineTo(15, 80);
      ctx.stroke();
    } else if (profile.weapon === 'walking_stick') {
      ctx.strokeStyle = '#78350f';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(0, 40);
      ctx.lineTo(0, 95);
      ctx.stroke();
    }
    ctx.restore();

    // 4. Head & Face
    ctx.fillStyle = profile.skinTone;
    ctx.beginPath();
    ctx.arc(0, -135, 22, 0, Math.PI * 2);
    ctx.fill();

    // Eyes & Expression
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.arc(-7, -137, 2.5, 0, Math.PI * 2);
    ctx.arc(7, -137, 2.5, 0, Math.PI * 2);
    ctx.fill();

    // Eyebrows (Stern / Heroic)
    ctx.strokeStyle = profile.hairColor;
    ctx.lineWidth = 2;
    ctx.beginPath();
    if (profile.expression === 'stern') {
      ctx.moveTo(-11, -144); ctx.lineTo(-4, -140);
      ctx.moveTo(11, -144); ctx.lineTo(4, -140);
    } else {
      ctx.moveTo(-11, -142); ctx.lineTo(-4, -142);
      ctx.moveTo(11, -142); ctx.lineTo(4, -142);
    }
    ctx.stroke();

    // 5. Headwear (Turban, Crown, Tricorne, Helmet)
    if (profile.headwear === 'turban') {
      ctx.fillStyle = profile.accentColor;
      ctx.beginPath();
      ctx.arc(0, -148, 24, Math.PI, 0);
      ctx.fill();
      // Jewel in center of turban
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(0, -152, 5, 0, Math.PI * 2);
      ctx.fill();
    } else if (profile.headwear === 'crown') {
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.moveTo(-20, -150);
      ctx.lineTo(-10, -168);
      ctx.lineTo(0, -154);
      ctx.lineTo(10, -168);
      ctx.lineTo(20, -150);
      ctx.closePath();
      ctx.fill();
    } else if (profile.headwear === 'tricorne' || profile.headwear === 'bicorne') {
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.ellipse(0, -155, 32, 12, 0, 0, Math.PI * 2);
      ctx.fill();
    } else if (profile.headwear === 'helmet') {
      ctx.fillStyle = '#475569';
      ctx.beginPath();
      ctx.arc(0, -146, 25, Math.PI, 0);
      ctx.fill();
    }

    ctx.restore();
  }
}
