/* ==========================================================================
   Smart History Education AI - Real Temporal Motion Video Renderer Engine
   ========================================================================== */

import { CharacterBible } from './characterBible.js';
import { AnimeCharacterEngine } from './animeCharacterEngine.js';

export class TemporalVideoEngine {
  constructor(canvasElement) {
    this.canvas = canvasElement;
    this.ctx = canvasElement.getContext('2d');

    this.is4K = false;
    this.width = 1920;
    this.height = 1080;
    this.canvas.width = this.width;
    this.canvas.height = this.height;

    this.variation = '3d_characters';

    this.particles = Array.from({ length: 70 }, () => ({
      x: Math.random() * this.width,
      y: Math.random() * this.height,
      radius: Math.random() * 3 + 1,
      vx: (Math.random() - 0.5) * 0.6,
      vy: (Math.random() - 0.5) * 0.6,
      alpha: Math.random() * 0.6 + 0.2
    }));

    this.rainDrops = Array.from({ length: 90 }, () => ({
      x: Math.random() * this.width,
      y: Math.random() * this.height,
      speed: Math.random() * 20 + 15,
      length: Math.random() * 30 + 20
    }));
  }

  setVariation(variationName) {
    this.variation = variationName || '3d_characters';
  }

  setQuality(is4K) {
    this.is4K = is4K;
    this.width = is4K ? 3840 : 1920;
    this.height = is4K ? 2160 : 1080;
    this.canvas.width = this.width;
    this.canvas.height = this.height;
  }

  /**
   * Main 60 FPS Temporal Render Loop.
   */
  renderFrame(scene, sceneProgress, totalProgress, subtitleText = '') {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.width, this.height);

    const env = scene ? (scene.envType || 'delhi_night_crowd') : 'delhi_night_crowd';

    // 1. Draw Specific Non-Battle Environment Background
    if (env === 'assembly_hall') {
      this.renderAssemblyChamberScene(ctx, scene, sceneProgress);
    } else if (env === 'clock_ticking') {
      this.renderTickingClockScene(ctx, scene, sceneProgress);
    } else if (env === 'colonial_map') {
      this.renderColonialMapScene(ctx, scene, sceneProgress);
    } else if (env === 'battlefield') {
      this.renderBattleChargeSequence(ctx, scene, sceneProgress);
    } else {
      this.renderDelhiNightCrowdScene(ctx, scene, sceneProgress);
    }

    // 2. Weather & Atmosphere
    if (scene && (scene.sfx === 'rain' || env === 'delhi_night_crowd')) {
      this.drawRainPhysics(ctx);
    }

    // 3. Particle Atmosphere
    this.drawParticles(ctx);

    // 4. Filters & HUD Overlay
    this.applyVariationFilters(ctx);
    this.drawHUD(ctx, scene);

    // 5. Subtitles
    if (subtitleText) {
      this.drawSubtitles(ctx, subtitleText);
    }
  }

  /* -------------------------------------------------------------------------- */
  /* NON-BATTLE VISUAL SCENE RENDERERS                                          */
  /* -------------------------------------------------------------------------- */

  // SCENE 1 & 2: Nighttime Delhi & Crowds Outside Constituent Assembly
  renderDelhiNightCrowdScene(ctx, scene, progress) {
    ctx.save();

    // Dark Monsoon Night Sky
    const skyGrad = ctx.createLinearGradient(0, 0, 0, this.height * 0.7);
    skyGrad.addColorStop(0, '#030712'); skyGrad.addColorStop(0.6, '#0f172a'); skyGrad.addColorStop(1, '#1e1b4b');
    ctx.fillStyle = skyGrad; ctx.fillRect(0, 0, this.width, this.height);

    // Dark Monsoon Clouds
    ctx.fillStyle = 'rgba(15, 23, 42, 0.75)';
    ctx.beginPath(); ctx.ellipse(400, 150, 450, 120, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(1200, 180, 550, 140, 0, 0, Math.PI * 2); ctx.fill();

    // Constituent Assembly Building Facade
    ctx.fillStyle = '#111827'; ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)'; ctx.lineWidth = 3;
    this.drawRoundedRect(ctx, 300, 220, 1320, 420, 16, true, true);

    // Columns & Illuminated Dome
    ctx.fillStyle = '#fbbf24'; ctx.beginPath(); ctx.arc(960, 220, 140, Math.PI, 0); ctx.fill();
    for (let i = 0; i < 10; i++) {
      ctx.fillStyle = '#374151'; ctx.fillRect(360 + i * 130, 270, 40, 370);
    }

    // Streetlights Glow
    const glowGrad = ctx.createRadialGradient(960, 420, 20, 960, 420, 600);
    glowGrad.addColorStop(0, 'rgba(245, 158, 11, 0.35)'); glowGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = glowGrad; ctx.fillRect(0, 0, this.width, this.height);

    // Massive Crowd Silhouettes
    const animPhase = progress * 20;
    const citizenBp = CharacterBible.getOrRegisterCharacter('Citizen', 'Public', 'Delhi');
    for (let i = 0; i < 8; i++) {
      const cx = 150 + i * 210 + Math.sin(animPhase + i) * 10;
      AnimeCharacterEngine.drawAnimeActor(ctx, cx, 720, citizenBp, 1.25, animPhase + i, 0, false, this.is4K, this.variation);
    }

    ctx.restore();
  }

  // SCENE 3: Brightly Lit Assembly Chamber Interior (Politicians & Journalists)
  renderAssemblyChamberScene(ctx, scene, progress) {
    ctx.save();

    // Brightly Lit Chamber Walls
    const chamberGrad = ctx.createLinearGradient(0, 0, 0, this.height);
    chamberGrad.addColorStop(0, '#451a03'); chamberGrad.addColorStop(0.5, '#78350f'); chamberGrad.addColorStop(1, '#0f172a');
    ctx.fillStyle = chamberGrad; ctx.fillRect(0, 0, this.width, this.height);

    // Grand Chandeliers & Warm Overhead Illumination
    const lightGlow = ctx.createRadialGradient(960, 150, 40, 960, 150, 700);
    lightGlow.addColorStop(0, 'rgba(254, 240, 138, 0.45)'); lightGlow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = lightGlow; ctx.fillRect(0, 0, this.width, this.height);

    // Wooden Speaker Podium & Desks
    ctx.fillStyle = '#292524'; ctx.strokeStyle = '#f59e0b'; ctx.lineWidth = 3;
    this.drawRoundedRect(ctx, 400, 520, 1120, 240, 16, true, true);

    // Microphones on Podium
    ctx.strokeStyle = '#cbd5e1'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(960, 520); ctx.lineTo(960, 440); ctx.stroke();
    ctx.fillStyle = '#020617'; ctx.beginPath(); ctx.arc(960, 435, 12, 0, Math.PI * 2); ctx.fill();

    // Politicians & Freedom Leaders Speaking
    const leaderBp = CharacterBible.getOrRegisterCharacter('Jawaharlal Nehru', 'Prime Minister', 'Assembly');
    const journalistBp = CharacterBible.getOrRegisterCharacter('Journalist', 'Press', 'Journalist');

    const animPhase = progress * 25;
    const isSpeaking = progress > 0.3;

    AnimeCharacterEngine.drawAnimeActor(ctx, 960, 640, leaderBp, 1.45, animPhase, 0, isSpeaking, this.is4K, this.variation);

    // Journalists seated taking notes
    for (let i = 0; i < 4; i++) {
      AnimeCharacterEngine.drawAnimeActor(ctx, 250 + i * 160, 660, journalistBp, 1.15, animPhase * 0.3 + i, 0, false, this.is4K, this.variation);
    }

    ctx.restore();
  }

  // SCENE 4: Historical Context of British Rule (Colonial Map & Transition)
  renderColonialMapScene(ctx, scene, progress) {
    ctx.save();

    // Vintage Sepia Background
    const mapGrad = ctx.createLinearGradient(0, 0, this.width, this.height);
    mapGrad.addColorStop(0, '#291e10'); mapGrad.addColorStop(0.5, '#45331d'); mapGrad.addColorStop(1, '#0f172a');
    ctx.fillStyle = mapGrad; ctx.fillRect(0, 0, this.width, this.height);

    // Historical Map Grid Lines
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.25)'; ctx.lineWidth = 1.5;
    for (let x = 100; x < this.width; x += 150) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, this.height); ctx.stroke();
    }
    for (let y = 100; y < this.height; y += 150) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.width, y); ctx.stroke();
    }

    // Map Title Label
    ctx.fillStyle = '#fbbf24'; ctx.font = 'bold 36px "Outfit", sans-serif'; ctx.textAlign = 'center';
    ctx.fillText('📜 Historical Record: British Colonial Rule in India (1757–1947)', this.width / 2, 220);

    const leaderBp = CharacterBible.getOrRegisterCharacter('Statesman', 'Leader', 'Assembly');
    AnimeCharacterEngine.drawAnimeActor(ctx, this.width / 2, 650, leaderBp, 1.35, progress * 15, 0, true, this.is4K, this.variation);

    ctx.restore();
  }

  // SCENE 5: Final Minutes Ticking Clock to Midnight
  renderTickingClockScene(ctx, scene, progress) {
    ctx.save();

    ctx.fillStyle = '#030712'; ctx.fillRect(0, 0, this.width, this.height);

    // Large Historic Clock Face
    const cx = this.width / 2; const cy = this.height / 2 - 20; const radius = 240;

    const clockGrad = ctx.createRadialGradient(cx, cy, 20, cx, cy, radius);
    clockGrad.addColorStop(0, '#fff7ed'); clockGrad.addColorStop(0.85, '#fef3c7'); clockGrad.addColorStop(1, '#78350f');
    ctx.fillStyle = clockGrad; ctx.strokeStyle = '#f59e0b'; ctx.lineWidth = 12;
    ctx.beginPath(); ctx.arc(cx, cy, radius, 0, Math.PI * 2); ctx.fill(); ctx.stroke();

    // Roman Numerals
    ctx.fillStyle = '#0f172a'; ctx.font = 'bold 32px "Outfit", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('XII', cx, cy - radius + 40);
    ctx.fillText('III', cx + radius - 40, cy);
    ctx.fillText('VI', cx, cy + radius - 40);
    ctx.fillText('IX', cx - radius + 40, cy);

    // Clock Hands Ticking to Midnight (11:59 -> 12:00)
    const secondAngle = (progress * Math.PI * 2);
    const minuteAngle = -Math.PI / 2 + progress * 0.1;

    // Hour Hand
    ctx.strokeStyle = '#020617'; ctx.lineWidth = 10; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx, cy - 130); ctx.stroke();

    // Minute Hand
    ctx.strokeStyle = '#020617'; ctx.lineWidth = 7;
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(minuteAngle) * 190, cy + Math.sin(minuteAngle) * 190); ctx.stroke();

    // Ticking Red Second Hand
    ctx.strokeStyle = '#ef4444'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(secondAngle) * 200, cy + Math.sin(secondAngle) * 200); ctx.stroke();

    ctx.fillStyle = '#ef4444'; ctx.beginPath(); ctx.arc(cx, cy, 10, 0, Math.PI * 2); ctx.fill();

    ctx.restore();
  }

  // Battle Charge (Executed ONLY when explicitly classified as battle!)
  renderBattleChargeSequence(ctx, scene, progress) {
    ctx.save();
    ctx.fillStyle = '#0f172a'; ctx.fillRect(0, 0, this.width, this.height);
    const charA = CharacterBible.getOrRegisterCharacter('Commander A', 'Leader', 'Forces');
    const charB = CharacterBible.getOrRegisterCharacter('Commander B', 'Leader', 'Forces');

    const chargeA_X = 300 + (this.width / 2 - 350) * progress;
    const chargeB_X = this.width - 300 - (this.width / 2 - 350) * progress;

    AnimeCharacterEngine.drawAnimeActor(ctx, chargeA_X, 650, charA, 1.4, progress * 30, 0, true, this.is4K, this.variation);
    AnimeCharacterEngine.drawAnimeActor(ctx, chargeB_X, 650, charB, 1.4, progress * 30 + 2, 0, true, this.is4K, this.variation);
    ctx.restore();
  }

  drawRainPhysics(ctx) {
    ctx.save(); ctx.strokeStyle = 'rgba(148, 163, 184, 0.45)'; ctx.lineWidth = this.is4K ? 3 : 1.5;
    this.rainDrops.forEach(drop => {
      drop.y += drop.speed; drop.x -= 4;
      if (drop.y > this.height) { drop.y = -20; drop.x = Math.random() * this.width; }
      ctx.beginPath(); ctx.moveTo(drop.x, drop.y); ctx.lineTo(drop.x - 5, drop.y + drop.length); ctx.stroke();
    });
    ctx.restore();
  }

  drawParticles(ctx) {
    ctx.save();
    this.particles.forEach(p => {
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0) p.x = this.width; if (p.x > this.width) p.x = 0;
      if (p.y < 0) p.y = this.height; if (p.y > this.height) p.y = 0;
      ctx.fillStyle = `rgba(245, 158, 11, ${p.alpha})`; ctx.beginPath(); ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2); ctx.fill();
    });
    ctx.restore();
  }

  applyVariationFilters(ctx) {
    ctx.save();
    if (this.variation === 'cinematic_characters') {
      ctx.fillStyle = 'rgba(245, 158, 11, 0.04)'; ctx.fillRect(0, 0, this.width, this.height);
    }
    ctx.restore();
  }

  drawHUD(ctx, scene) {
    ctx.save();
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.35)'; ctx.lineWidth = 4; ctx.strokeRect(30, 30, this.width - 60, this.height - 60);

    // Watermark Label
    ctx.fillStyle = 'rgba(15, 23, 42, 0.9)'; ctx.strokeStyle = '#f59e0b'; ctx.lineWidth = 2;
    this.drawRoundedRect(ctx, this.width - 560, 45, 500, 48, 24, true, true);
    ctx.fillStyle = '#fbbf24'; ctx.font = `bold ${this.is4K ? 24 : 18}px "Outfit", sans-serif`; ctx.textAlign = 'center';
    ctx.fillText('📜 Fact-Checked Record | 🎬 Content-Accurate Engine', this.width - 310, 75);

    // AI Prompt HUD Box
    if (scene && scene.aiPrompt) {
      const promptW = this.width - 240; const promptX = 120; const promptY = 110;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.88)'; ctx.strokeStyle = 'rgba(245, 158, 11, 0.5)'; ctx.lineWidth = 1.5;
      this.drawRoundedRect(ctx, promptX, promptY, promptW, 55, 10, true, true);

      ctx.fillStyle = '#f59e0b'; ctx.font = 'bold 16px "Outfit", sans-serif'; ctx.textAlign = 'left';
      ctx.fillText('🤖 SCENE PROMPT:', promptX + 20, promptY + 33);

      ctx.fillStyle = '#e2e8f0'; ctx.font = '15px "Inter", sans-serif';
      const truncatedPrompt = scene.aiPrompt.length > 120 ? scene.aiPrompt.substring(0, 117) + '...' : scene.aiPrompt;
      ctx.fillText(truncatedPrompt, promptX + 200, promptY + 33);
    }
    ctx.restore();
  }

  drawSubtitles(ctx, subtitleText) {
    ctx.save();
    const barW = this.width - 240; const barH = 85; const barX = 120; const barY = this.height - 145;
    ctx.fillStyle = 'rgba(10, 14, 23, 0.9)'; ctx.strokeStyle = 'rgba(245, 158, 11, 0.5)'; ctx.lineWidth = 2;
    this.drawRoundedRect(ctx, barX, barY, barW, barH, 14, true, true);

    ctx.fillStyle = '#f59e0b'; ctx.font = 'bold 20px "Outfit", sans-serif'; ctx.textAlign = 'left';
    ctx.fillText('🗣️ SPOKEN NARRATION:', barX + 25, barY + 48);

    ctx.fillStyle = '#ffffff'; ctx.font = '500 24px "Inter", sans-serif';
    ctx.fillText(subtitleText, barX + 280, barY + 48);
    ctx.restore();
  }

  drawRoundedRect(ctx, x, y, width, height, radius, fill, stroke) {
    ctx.beginPath(); ctx.moveTo(x + radius, y); ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius); ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height); ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius); ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y); ctx.closePath();
    if (fill) ctx.fill(); if (stroke) ctx.stroke();
  }
}
