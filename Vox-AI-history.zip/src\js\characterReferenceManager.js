/* ==========================================================================
   Smart History Education AI - Character Reference Image Manager
   ========================================================================== */

export class CharacterReferenceManager {
  constructor() {
    this.references = new Map();
  }

  addReference(id, name, role, dataUrl, imageElement) {
    const charRecord = {
      id: id || `char_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      name: name || 'Historical Leader',
      role: role || 'Leader',
      dataUrl,
      imageElement,
      sceneAssignments: [],
      createdAt: new Date().toISOString()
    };

    this.references.set(charRecord.id, charRecord);
    console.log(`[Character Reference] Added character "${charRecord.name}" (${charRecord.role})`);
    return charRecord;
  }

  removeReference(id) {
    if (this.references.has(id)) {
      this.references.delete(id);
      console.log(`[Character Reference] Removed character ${id}`);
    }
  }

  getAllReferences() {
    return Array.from(this.references.values());
  }

  findMatchingReference(nameOrRole) {
    if (!nameOrRole) return null;
    const lower = nameOrRole.toLowerCase();

    for (const ref of this.references.values()) {
      if (ref.name.toLowerCase().includes(lower) || lower.includes(ref.name.toLowerCase())) {
        return ref;
      }
      if (ref.role.toLowerCase().includes(lower) || lower.includes(ref.role.toLowerCase())) {
        return ref;
      }
    }

    // Return first available reference if present
    const first = this.getAllReferences()[0];
    return first || null;
  }

  clear() {
    this.references.clear();
  }
}

export const globalCharacterRefMgr = new CharacterReferenceManager();
